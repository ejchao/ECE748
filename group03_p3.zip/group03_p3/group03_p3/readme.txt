To run regression:
  1) Enter the "project_benches/test_top" directory.
  2) Edit "sim/Makefile" to point to the correct UVMF base directory.
  3) in the "sim/" directory, type "make regress" to run the test regression.

The testplan is stored at "project_benches/test_top/sim/lc3_test_plan.xml".
The transcript is saved as transcript_copy in the sim directory