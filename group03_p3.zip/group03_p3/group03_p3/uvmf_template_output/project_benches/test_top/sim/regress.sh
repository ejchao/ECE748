make clean
rm -rf *.ucdb
make cli TEST_NAME=test_top TEST_SEED=2121431480
cp transcript transcript_copy
make merge_coverage
make view_coverage
